/*
 * =============================================================================
 *
 *   Copyright (c) 2011-2026 Thymeleaf (http://www.thymeleaf.org)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package org.thymeleaf.model;

/**
 * <p>
 *   Event interface defining a Processing Instruction.
 * </p>
 * <p>
 *   Note that any implementations of this interface should be <strong>immutable</strong>.
 * </p>
 *
 * @author Daniel Fern&aacute;ndez
 * @since 3.0.0
 * 
 */
public interface IProcessingInstruction extends ITemplateEvent {

    /**
     * <p>
     *   Returns the target of the Processing Instruction.
     * </p>
     *
     * @return the Processing Instruction target.
     */
    public String getTarget();

    /**
     * <p>
     *   Returns the content of the Processing Instruction.
     * </p>
     *
     * @return the Processing Instruction content.
     */
    public String getContent();

    /**
     * <p>
     *   Returns the complete Processing Instruction as a String.
     * </p>
     *
     * @return the complete Processing Instruction.
     */
    public String getProcessingInstruction();

}
