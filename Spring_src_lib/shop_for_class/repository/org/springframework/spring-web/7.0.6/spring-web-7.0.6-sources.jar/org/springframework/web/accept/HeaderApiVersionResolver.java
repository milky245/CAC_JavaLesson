/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.web.accept;

import jakarta.servlet.http.HttpServletRequest;
import org.jspecify.annotations.Nullable;

/**
 * {@link ApiVersionResolver} that extracts the version from a header.
 *
 * @author Rossen Stoyanchev
 * @since 7.0
 */
public class HeaderApiVersionResolver implements ApiVersionResolver {

	private final String headerName;


	public HeaderApiVersionResolver(String headerName) {
		this.headerName = headerName;
	}


	@Override
	public @Nullable String resolveVersion(HttpServletRequest request) {
		return request.getHeader(this.headerName);
	}

}
