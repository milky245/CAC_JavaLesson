/**
 * 選択ソート
 * 入力された数字10個を降順に並べ替えるプログラムを作成してください。
 * 
 * ソートアルゴリズムには様々な種類がありますが、今回は選択ソートを使用します。
 * 
 * まず、並べ替える数字の入っている箱が横一列に並んでいるとイメージします。
 * 最初は1個めの数字と他の箱を比較し、一番大きい箱（MAX値）を選択します。MAX値と一番左（1個めの箱）の値を交換します。
 * 次は2個め～最後までの箱を比較し、MAX値を調べ、MAX値を2個目の箱に移動します。
 * これをすべての箱について繰り返せば、最終的に左から順に大きな数字に並べ替えることができます。
 * このように、数値の中から一番大きい(あるいは小さい)値を選択して並べ替えていくソートアルゴリズムを、選択ソートと読んでいます。
 * 
 * 参考：https://gigazine.net/news/20140501-sorting/
 * 
 * 実行例：
 * 
 * ソート前：
 * 15 63 50 1 4 68 100 3 42 7 
 * ソート後：
 * 1 3 4 7 15 42 50 63 68 100 
 * 
 */
package section04_summary.challenge06;

import java.util.Random;
import java.util.Scanner;

public class SelectionSortB {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();
		int[] array = new int[10];

		// 数字を10個用意
		for (int i = 0; i < array.length; i++) {
			array[i] = random.nextInt(100) + 1;
		}

		// ソート前を出力
		System.out.println("ソート前：");
		for (int i : array) {
			System.out.print(i + " ");
		}

		// ソートの実施
		// 0番目～最後までを対象とする
		for (int i = 0; i < array.length; i++) {
			// i+1番目～最後までを比較対象とする
			for (int j = i + 1; j < array.length; j++) {
				// j番目がi番目より小さいなら、数字を入れ替える
				if (array[j] < array[i]) {
					// iの数字を避難
					int tmp = array[i];
					// jの数字をiへ代入
					array[i] = array[j];
					// 避難した数字をjに代入
					array[j] = tmp;
				}
			}
		}

		// ソート後を出力
		System.out.println("\nソート後：");
		for (int i : array) {
			System.out.print(i + " ");
		}
		
		stdIn.close();

	}

}
