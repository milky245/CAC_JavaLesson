/**
 * 素数判定
 * 特定の数字１個の判定
 *
 * 1と自分自身以外に正の約数を持たない自然数のことを素数と言います。
 * 言い換えると、2以上n未満の約数を持たない自然数nを素数といいます。
 * ※ちなみに、自然数nを割り切れる自然数xはn/2以下の数字です。
 *
 * 入力した整数が素数であることを判定するプログラムを作成してください。
 *
 * 実行例：
 * （素数である場合）
 * 整数を入力してください＞2749
 * 2749は素数です
 *
 * （素数でない場合）
 * 整数を入力してください＞100
 * 100は素数ではありません。
 *
 * ====
 * ScannerクラスはBufferedReaderクラスの仲間で、標準入力するための機能を持ちます。
 * 文字列を入力する場合は「String target = stdIn.next();」のように使います。
 * 整数を入力する場合は「int target = stdIn.nextInt();」のように使います。
 * BRと違って、文字と数値の変換が不要です。
 */

package section03_repetition.challenge01;

import java.util.Scanner;

public class PrimeNumber_level1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		// 判定する数字を入力
		System.out.print("整数を入力してください＞");
		int target = stdIn.nextInt();

		// 数字の2
		final int NUM_2 = 2;
		// 数字の0
		final int NUM_0 = 0;
		// 判定結果の真偽
		boolean isPrimeNumber = true;

		// 判定を行うループ
		// 2～入力値の1/2までを繰り返す
		for (int i = NUM_2; i <= target / NUM_2; i++) {
			// 入力値をカウンタ変数iで割り切れる場合素数ではないので
			// 判定を終わる
			if (target % i == NUM_0) {
				isPrimeNumber = false;
				break;
			}
		}

		// 最終結果の表示
		if (isPrimeNumber) {
			System.out.println(target + "は素数です。");
		} else {
			System.out.println(target + "は素数ではありません。");
		}
		
		stdIn.close();

	}

}
